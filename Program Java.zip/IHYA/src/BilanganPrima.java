/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RIZKY
 */
import java.util.Scanner;

public class BilanganPrima {

    public static void main(String[] args) {
        Scanner Ihya_ringu = new Scanner(System.in);
        System.out.println("Masukkan nilai Bil = ");
        double Bil = Ihya_ringu.nextDouble();
        int b = 2;
        do {
            if ((Bil / b) == (int)(Bil / b)) {
                System.out.println(Bil + "bukan bilangan prima");
                break;
            } else {
                b = b + 1;
            } 
        } while (b <= (Bil - 1));
        if (b == Bil) {
            System.out.println(Bil + "Bilangan Prima");
        }
    }
}
