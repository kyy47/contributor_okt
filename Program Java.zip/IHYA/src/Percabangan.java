
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RIZKY
 */
public class Percabangan {
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.print("Masukkan apa mau anda : ");
        int Mau_Anda = input.nextInt();
       switch(Mau_Anda){
           case 1:
               System.out.println("KYY");
               break;
           case 2:  
               System.out.println("JINGGA");
               break;
           case 3:  
               System.out.println("IYA");
               break;
           case 4:
               System.out.println("PALPALE");
               break;
           default : 
               System.out.println("AUSI");
       }
    }
}
