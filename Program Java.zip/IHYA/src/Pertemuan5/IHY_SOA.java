/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pertemuan5;

import java.util.Scanner;

/**
 *
 * @author RIZKY
 */
public class IHY_SOA {
    public static void main(String[] args) {
        Scanner Limin = new Scanner(System.in);
        double C , F, R, K;
        System.out.print("Masukkan nilai C = ");
        C = Limin.nextDouble();
        F = (9.0/5.0) * C + 32;
        R = (4.0/5.0)*C;
        K = 273 + C ;
        System.out.println("NILAI F ADALAH = " + F 
               + "\nNILAI R ADALAH = " + R 
        + "\nNILAI K ADALAH = " + K);
    }
}
