/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pertemuan5;

import java.util.Scanner;


 
public class PUSING {
    public static void main(String[] args) {
        double c , f ,r , k;
        Scanner ihyaa = new Scanner (System .in);
        System.out.println("masukan  nilai c");
        c = ihyaa.nextDouble();
        f = (9.0/5.0)*c+32;
        r = (4.0/5.0)*c;
        k = 273 + c;
        System.out.println("f = " +f );
        System.out.println("r = " +r );
        System.out.println("k = " +k );
    }
}
