/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pertemuan5;

import java.util.Scanner;

/**
 *
 * @author RIZKY
 */
public class bang_limin {
    public static void main(String[] args) {
        double c , f , r , k;
        Scanner ihya = new Scanner(System.in);
        System.out.print("MASUKKAN NILAI C = ");
        c = ihya.nextDouble();
        f = (9.0/5.0)*c  + 32;
        r = (4.0/5.0)*c;
        k = 273 + c;
        System.out.println("f adalah " + f);
        System.out.println("r adalah " + r);
        System.out.println("k adalah " + k);
                
    }
    
}
