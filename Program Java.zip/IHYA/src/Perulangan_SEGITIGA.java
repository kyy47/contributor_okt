
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author RIZKY
 */
public class Perulangan_SEGITIGA {

    public static void main(String[] args) {
        Scanner Limin = new Scanner(System.in);
        System.out.print("MASUKKAN NILAI n : ");
        int n = Limin.nextInt();
        for (int i = 0; i <= (n/2) ; i++) {
            for (int j = 0; j < n; j++) {
                String Test = ((j >= (n / 2) - i) && (j <= (n / 2) + i)) ? "1" : "";
                System.out.print(Test);
            }        System.out.print("\n");
        }

    }
}
