/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RIZKY
 */
import java.util.Scanner;
public class Segitiga_Sama_Sisi {

    public static void main(String[] args) {
        Scanner Ihya = new Scanner(System.in);
                System.out.println("Masukkan nilai n = ");
                int n = Ihya.nextInt();
        for (int i = 1; i <= n; i++) {
            for (int j = n; j > i; j--) {
                System.out.print(" ");
            }
            for (int k = 1; k <= i; k++) {
                System.out.print("* ");
            }
            System.out.println();
        }
        System.out.println();
        System.out.print("baris = " + n);
    }
}

