
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RIZKY
 */
public class Segitiga_siku {

    public static void main(String[] args) {
        Scanner KYY = new Scanner(System.in);
        System.out.println("Masukkan mau baris nya berapa ? ");
        int baris  = KYY.nextInt();
        int x = baris + 1 , y;
        for (int i = 1; i <= baris; i++) {
            for (int j = 1; j <= baris; j++) {
                y = i + j;
              String limin = (x <= y)? "1" : " ";
                System.out.print(limin);
            }System.out.print("\n");
        }
    }
}
