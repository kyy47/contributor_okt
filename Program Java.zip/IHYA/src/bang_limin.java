
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RIZKY
 */
//tentukan nilai c dengan rumus c = a + b + z . a , b , z dibaca dari input
//a  = 12 b =  
public class bang_limin {
    public static void main(String[] args) {
     Scanner oha_ncango = new Scanner(System.in);
        double a , b ,c ;
        System.out.print("masukkan nilai a :");
         a = oha_ncango.nextDouble();
        System.out.print("masukkan nilai b :");
         b = oha_ncango.nextDouble();
                 
        
        
         c = a / b ;
        System.out.println("hasi pertambahan a dan b  adalah :" + c);
        
    }
}
