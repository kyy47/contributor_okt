
package kalkulator;

import java.util.Scanner;
public class Kalkulator {

    
    public static void main(String[] args) {
        System.out.println("=======SELAMAT DATANG DI KALKULATOR SEDERHANA========");
        Scanner input = new Scanner (System.in);
        int bil1 , bil2, pill, hasil = 0;
        System.out.println("1. Pejumlahan ");
        System.out.println("2. Pengurangan ");
        System.out.println("3. Perkalian ");
        System.out.println("4. Pembagiann ");
        System.out.println("----------------------------------------");
        System.out.print("masukan bilangan 1 =");
        bil1 = input.nextInt();
        System.out.print("masukan bilangan 2 =");
        bil2 = input.nextInt();
        System.out.print("Pilihan oprasi = ");
        pill= input.nextInt();
        switch (pill){
            case 1 :hasil= bil1+bil2;break;
            case 2 :hasil = bil1-bil2;break;
            case 3 :hasil = bil1*bil2;break;
            case 4 :hasil = bil1/bil2;break;
            default : System.out.println("pilihan anda salah");
        }
            System.out.println("Hasil = "+ hasil);
        }
    }
    

